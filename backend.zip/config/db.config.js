module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "fans",
    DB: "api_prueba",
    PORT: 3306
};
